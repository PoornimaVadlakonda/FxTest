#!/bin/bash
ulimit -c unlimited
export LD_LIBRARY_PATH=.
./FxTestEngineForTest ./fxconfig.json
